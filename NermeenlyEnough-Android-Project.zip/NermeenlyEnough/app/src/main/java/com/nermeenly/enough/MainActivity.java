package com.nermeenly.enough;

import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.webkit.*;import android.widget.*;import android.net.Uri;

public class MainActivity extends Activity {
    WebView web;
    final String HOME="https://nermeenly.blogspot.com/?m=1";
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT); getWindow().setNavigationBarColor(Color.rgb(143,38,53));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        web=new WebView(this); setContentView(web); WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true); s.setBuiltInZoomControls(true); s.setDisplayZoomControls(false); s.setLoadWithOverviewMode(false); s.setUseWideViewPort(false);
        web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,String u){ if(u.startsWith("http://")||u.startsWith("https://")){v.loadUrl(u);return true;} try{startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(u)));}catch(Exception ignored){} return true; }});
        web.setWebChromeClient(new WebChromeClient()); web.setBackgroundColor(Color.TRANSPARENT); web.setOverScrollMode(View.OVER_SCROLL_NEVER); web.loadUrl(HOME);
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}

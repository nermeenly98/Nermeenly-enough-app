# Nermeenly enough — Android app

WebView wrapper for https://nermeenly.blogspot.com/?m=1

Features: edge-to-edge transparent status bar, wine navigation bar, pinch zoom, JavaScript/DOM storage, media playback settings, internal web navigation, Back button handling, hardware acceleration.

Build with Android Studio or GitHub Actions. The included workflow can build a debug APK from the repository.
